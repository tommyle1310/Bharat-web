(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/http.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "authApi",
    ()=>authApi,
    "buyerApi",
    ()=>buyerApi
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
;
const buyerApi = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: 'http://localhost:1310/kmsg/buyer',
    timeout: 120000,
    headers: {
        'Content-Type': 'application/json'
    }
});
const authApi = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: 'http://13.203.1.159:8002',
    timeout: 15000,
    headers: {
        'Content-Type': 'application/json'
    }
});
// Optional: attach token from localStorage (web-only) under 'web-token'
buyerApi.interceptors.request.use((config)=>{
    try {
        const token = ("TURBOPACK compile-time truthy", 1) ? localStorage.getItem('web-token') : "TURBOPACK unreachable";
        if (token) {
            config.headers.Authorization = "Bearer ".concat(token);
        }
    } catch (e) {}
    return config;
});
buyerApi.interceptors.response.use((res)=>res, async (error)=>{
    var _error_response;
    const original = error.config;
    if ((error === null || error === void 0 ? void 0 : (_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.status) === 401 && !original._retry) {
        original._retry = true;
        try {
            var _r_data;
            const refresh = ("TURBOPACK compile-time truthy", 1) ? localStorage.getItem('web-refresh') : "TURBOPACK unreachable";
            if (!refresh) throw error;
            const r = await authApi.post('/refresh', {
                refreshToken: refresh
            });
            const accessToken = (_r_data = r.data) === null || _r_data === void 0 ? void 0 : _r_data.accessToken;
            if (accessToken && "object" !== 'undefined') {
                localStorage.setItem('web-token', accessToken);
            }
            original.headers.Authorization = "Bearer ".concat(accessToken);
            return buyerApi(original);
        } catch (e) {
            return Promise.reject(e);
        }
    }
    return Promise.reject(error);
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/services/vehicles.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "vehicleService",
    ()=>vehicleService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$http$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/http.ts [app-client] (ecmascript)");
;
const vehicleService = {
    async getGroups (businessVertical) {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$http$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buyerApi"].get("/vehicles/groups", {
            params: {
                businessVertical
            }
        });
        return res.data.data;
    },
    async getVehiclesByGroup (params) {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$http$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buyerApi"].get("/vehicles/groups/list", {
            params: {
                type: params.type,
                title: params.title,
                businessVertical: params.businessVertical
            }
        });
        return res.data.data;
    },
    async getVehicleById (vehicleId) {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$http$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buyerApi"].get("/vehicles/".concat(vehicleId));
        return res.data.data;
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/vehicles/[id]/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>VehicleDetailPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$services$2f$vehicles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/services/vehicles.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function VehicleDetailPage(param) {
    let { params } = param;
    _s();
    const { id } = params;
    const [vehicle, setVehicle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VehicleDetailPage.useEffect": ()=>{
            let mounted = true;
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$services$2f$vehicles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["vehicleService"].getVehicleById(id).then({
                "VehicleDetailPage.useEffect": (v)=>{
                    if (mounted) setVehicle(v);
                }
            }["VehicleDetailPage.useEffect"]).catch({
                "VehicleDetailPage.useEffect": ()=>{
                    if (mounted) setError("Unable to load vehicle details.");
                }
            }["VehicleDetailPage.useEffect"]);
            return ({
                "VehicleDetailPage.useEffect": ()=>{
                    mounted = false;
                }
            })["VehicleDetailPage.useEffect"];
        }
    }["VehicleDetailPage.useEffect"], [
        id
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-6 space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-xl font-semibold",
                children: [
                    "Vehicle #",
                    id
                ]
            }, void 0, true, {
                fileName: "[project]/app/vehicles/[id]/page.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, this),
            vehicle ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                className: "text-xs bg-muted p-4 rounded-md overflow-auto",
                children: JSON.stringify(vehicle, null, 2)
            }, void 0, false, {
                fileName: "[project]/app/vehicles/[id]/page.tsx",
                lineNumber: 29,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-muted-foreground",
                children: error || "Loading..."
            }, void 0, false, {
                fileName: "[project]/app/vehicles/[id]/page.tsx",
                lineNumber: 31,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/vehicles/[id]/page.tsx",
        lineNumber: 26,
        columnNumber: 5
    }, this);
}
_s(VehicleDetailPage, "mRhGWJM9si2zgcpNA0tYL05qHxE=");
_c = VehicleDetailPage;
var _c;
__turbopack_context__.k.register(_c, "VehicleDetailPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_d5e7efa3._.js.map
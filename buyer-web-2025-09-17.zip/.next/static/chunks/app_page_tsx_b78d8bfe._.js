(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_540b3fcd._.js",
  "static/chunks/node_modules_44012c4b._.js"
],
    source: "dynamic"
});

(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_ea5d3ef2._.js",
  "static/chunks/_4df52489._.js"
],
    source: "dynamic"
});

(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__28bc9c2a._.css",
  "static/chunks/node_modules_0e3c57c4._.js",
  "static/chunks/_de4a861c._.js"
],
    source: "dynamic"
});

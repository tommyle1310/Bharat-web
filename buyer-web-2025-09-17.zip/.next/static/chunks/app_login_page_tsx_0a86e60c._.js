(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_0c24a24c._.js",
  "static/chunks/_84b308bd._.js"
],
    source: "dynamic"
});

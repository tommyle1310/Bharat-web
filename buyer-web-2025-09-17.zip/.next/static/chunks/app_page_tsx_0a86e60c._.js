(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_5a1ba085._.js",
  "static/chunks/_e44bc4db._.js"
],
    source: "dynamic"
});
